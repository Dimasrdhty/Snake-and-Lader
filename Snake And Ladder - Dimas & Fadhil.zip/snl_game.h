void initGrid(int,int);
void display_message(const char *text, int length);
void render_board();
void plot_player(int player_id, int position);
int roll_dice();
void init_snakes_ladders();